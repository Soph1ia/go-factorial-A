# Overview

[![Go Reference](https://pkg.go.dev/badge/github.com/aws/aws-lambda-go/lambda/messages.svg)](https://pkg.go.dev/github.com/aws/aws-lambda-go/lambda/messages)

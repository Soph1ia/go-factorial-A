# Overview

[![Go Reference](https://pkg.go.dev/badge/github.com/aws/aws-lambda-go/lambdacontext.svg)](https://pkg.go.dev/github.com/aws/aws-lambda-go/lambdacontext)
